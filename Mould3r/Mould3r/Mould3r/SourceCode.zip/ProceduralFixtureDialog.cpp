#include "ProceduralFixtureDialog.h"
#include "WindowEffects.h"   // DWM corner rounding, matching the sibling dialogs

ProceduralFixtureDialog::ProceduralFixtureDialog(wxWindow* parent,
    const FixtureDefinition& def)
    : wxDialog(parent, wxID_ANY,
        def.kind == FixtureKind::Dynamic ? "Dynamic Box Fixture"
                                         : "Parametric Box Fixture",
        wxDefaultPosition, wxSize(360, 240),
        wxDEFAULT_DIALOG_STYLE | wxSTAY_ON_TOP),
    m_kind(def.kind)
{
    const bool dyn = (m_kind == FixtureKind::Dynamic);

    auto* main = new wxBoxSizer(wxVERTICAL);

    // One-line caption explaining what the three fields mean for this kind.
    auto* caption = new wxStaticText(this, wxID_ANY, dyn
        ? "Minimum clearance from the parts and origin to each face.\n"
          "The box auto-fits the scene and updates as objects move."
        : "Total box dimensions, centred on the origin and split into\n"
          "two halves at the parting plane.");
    main->Add(caption, 0, wxLEFT | wxRIGHT | wxTOP, 14);
    main->AddSpacer(4);

    // Seed the fields from the matching param struct.
    const float ix = dyn ? def.dynamic.clearanceX : def.parametric.sizeX;
    const float iy = dyn ? def.dynamic.clearanceY : def.parametric.sizeY;
    const float iz = dyn ? def.dynamic.clearanceZ : def.parametric.sizeZ;

    auto addRow = [&](const wxString& label, wxTextCtrl*& ctrl, float initVal)
    {
        auto* row = new wxBoxSizer(wxHORIZONTAL);
        auto* lbl = new wxStaticText(this, wxID_ANY, label,
            wxDefaultPosition, wxSize(90, -1));
        ctrl = new wxTextCtrl(this, wxID_ANY,
            wxString::Format("%.3f", initVal),
            wxDefaultPosition, wxSize(120, -1));
        auto* unit = new wxStaticText(this, wxID_ANY, "mm");

        row->Add(lbl, 0, wxALIGN_CENTER_VERTICAL | wxRIGHT, 6);
        row->Add(ctrl, 0, wxALIGN_CENTER_VERTICAL | wxRIGHT, 4);
        row->Add(unit, 0, wxALIGN_CENTER_VERTICAL);
        main->Add(row, 0, wxEXPAND | wxLEFT | wxRIGHT | wxTOP, 14);
    };

    addRow(dyn ? "Clearance X:" : "Width (X):", m_ctrlX, ix);
    addRow(dyn ? "Clearance Y:" : "Height (Y):", m_ctrlY, iy);
    addRow(dyn ? "Clearance Z:" : "Depth (Z):", m_ctrlZ, iz);

    // Side injection: the injection point may sit anywhere on the box's
    // perimeter (FixtureDefinition::allowPerimeterInjection). Seeded from the
    // definition — the picker turns it on for a new box fixture.
    main->AddSpacer(6);
    m_sideInjection = new wxCheckBox(this, wxID_ANY, "Side injection (anywhere on the perimeter)");
    m_sideInjection->SetValue(def.allowPerimeterInjection);
    main->Add(m_sideInjection, 0, wxLEFT | wxRIGHT | wxTOP, 14);

    // Top-plane injection: whether the box's top face offers injection
    // points (see TopInjection). Order matches the enum.
    {
        auto* row = new wxBoxSizer(wxHORIZONTAL);
        auto* lbl = new wxStaticText(this, wxID_ANY, "Top injection:",
            wxDefaultPosition, wxSize(90, -1));
        m_topInjection = new wxChoice(this, wxID_ANY,
            wxDefaultPosition, wxSize(150, -1));
        m_topInjection->Append("Off");
        m_topInjection->Append("Centre point (0, 0)");
        m_topInjection->Append("Anywhere on top");
        m_topInjection->SetSelection(def.topInjection == TopInjection::Centre   ? 1
                                   : def.topInjection == TopInjection::Anywhere ? 2 : 0);
        row->Add(lbl, 0, wxALIGN_CENTER_VERTICAL | wxRIGHT, 6);
        row->Add(m_topInjection, 0, wxALIGN_CENTER_VERTICAL);
        main->Add(row, 0, wxEXPAND | wxLEFT | wxRIGHT | wxTOP, 14);
    }

    main->AddSpacer(10);
    main->Add(CreateButtonSizer(wxOK | wxCANCEL), 0,
        wxEXPAND | wxLEFT | wxRIGHT | wxBOTTOM, 14);

    SetSizer(main);
    Fit();
    CentreOnParent();
    WindowEffects::ApplyRoundedCorners(this);

    // Validate on OK rather than letting the dialog's default handler end it,
    // so a non-positive extent can't reach BRepPrimAPI_MakeBox.
    Bind(wxEVT_BUTTON, &ProceduralFixtureDialog::OnOK, this, wxID_OK);

    m_ctrlX->SetFocus();
    m_ctrlX->SelectAll();
}

float ProceduralFixtureDialog::ParseField(wxTextCtrl* ctrl, float fallback) const
{
    double val = 0.0;
    if (!ctrl->GetValue().ToDouble(&val))
        return fallback;
    return static_cast<float>(val);
}

void ProceduralFixtureDialog::OnOK(wxCommandEvent&)
{
    // Fallback of -1 makes an unparseable field fail the positivity check
    // below rather than silently defaulting to something valid.
    const float x = ParseField(m_ctrlX, -1.0f);
    const float y = ParseField(m_ctrlY, -1.0f);
    const float z = ParseField(m_ctrlZ, -1.0f);

    if (x <= 0.0f || y <= 0.0f || z <= 0.0f)
    {
        const wxString what = (m_kind == FixtureKind::Dynamic)
            ? "Clearances" : "Dimensions";
        wxMessageBox(what + " must be greater than zero.",
            "Invalid value", wxOK | wxICON_WARNING, this);
        return;   // not skipped → the dialog stays open for correction
    }

    // A box fixture has no fixed injection points, so with both options off
    // there would be nowhere to put the sprue.
    if (!GetAllowPerimeterInjection() && GetTopInjection() == TopInjection::Off)
    {
        wxMessageBox("Turn on side injection or choose a top injection option, "
            "so the sprue has somewhere to go.",
            "No injection point", wxOK | wxICON_WARNING, this);
        return;
    }
    EndModal(wxID_OK);
}

ParametricFixtureParams ProceduralFixtureDialog::GetParametric() const
{
    ParametricFixtureParams p;
    p.sizeX = ParseField(m_ctrlX, p.sizeX);
    p.sizeY = ParseField(m_ctrlY, p.sizeY);
    p.sizeZ = ParseField(m_ctrlZ, p.sizeZ);
    return p;
}

bool ProceduralFixtureDialog::GetAllowPerimeterInjection() const
{
    return m_sideInjection && m_sideInjection->GetValue();
}

TopInjection ProceduralFixtureDialog::GetTopInjection() const
{
    const int sel = m_topInjection ? m_topInjection->GetSelection() : 0;
    if (sel == 1) return TopInjection::Centre;
    if (sel == 2) return TopInjection::Anywhere;
    return TopInjection::Off;
}

DynamicFixtureParams ProceduralFixtureDialog::GetDynamic() const
{
    DynamicFixtureParams d;
    d.clearanceX = ParseField(m_ctrlX, d.clearanceX);
    d.clearanceY = ParseField(m_ctrlY, d.clearanceY);
    d.clearanceZ = ParseField(m_ctrlZ, d.clearanceZ);
    return d;
}
