#pragma once

#include <glad/glad.h>
#include <wx/glcanvas.h>
#include <vector>
#include <array>
#include <functional>   // std::function for scene-mutation callback

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include <opencascade/TopoDS.hxx>
#include <opencascade/TopoDS_Face.hxx>
#include <opencascade/TopExp_Explorer.hxx>
#include <opencascade/BRep_Tool.hxx>
#include <opencascade/Poly_Triangulation.hxx>
#include <opencascade/TopLoc_Location.hxx>
#include <opencascade/gp_Pnt.hxx>
#include <opencascade/gp_Trsf.hxx>
#include <opencascade/BRepBuilderAPI_Transform.hxx>
#include <opencascade/STEPControl_Reader.hxx>
#include <opencascade/STEPControl_Writer.hxx>
#include <opencascade/IFSelect_ReturnStatus.hxx>
#include <opencascade/TopoDS_Shape.hxx>

#include "camera.h"
#include "FileImporter.h"
#include "MeshBoolean.h"
#include "GridRenderer.h"
#include "shaders.h"
#include "MainFrame.h"
#include "MouldFeature.h"
#include "ProjectFile.h"

struct GPUMesh
{
    GLuint vao = 0;
    GLuint vbo = 0;
    GLuint ebo = 0;
    GLsizei indexCount = 0;

    void Destroy()
    {
        if (ebo) { glDeleteBuffers(1, &ebo);         ebo = 0; }
        if (vbo) { glDeleteBuffers(1, &vbo);         vbo = 0; }
        if (vao) { glDeleteVertexArrays(1, &vao);    vao = 0; }
        indexCount = 0;
    }
};

enum class ObjectRole { Fixture, Imported };

// The geometry lineage of an imported body, decided at import time from the
// file extension: STEP/STP -> Brep (native BREP, STEP toolchain), STL/OBJ ->
// Mesh (kept as triangles, mesh toolchain). Drives the scene-level mesh-type
// flag (see GLCanvas::m_sceneIsMesh) and, in later stages, whether a body is
// cut as a BREP solid or as a mesh, and whether the scene exports STEP or STL.
enum class SourceFormat { Brep, Mesh };

struct SceneObject
{
    GPUMesh    mesh;
    ObjectRole role = ObjectRole::Imported;
    // Lineage of this body's source file. Defaults to Brep so STEP objects and
    // any non-imported body (e.g. a fixture) read as BREP without extra work;
    // ImportBodyInto sets it to Mesh for STL/OBJ. Always derivable from
    // sourcePath's extension, so it need not be persisted — project load
    // re-derives it by re-importing (see RestoreObject / RestoreInsert).
    SourceFormat format = SourceFormat::Brep;
    std::string sourcePath;
    TopoDS_Shape mouldShape;
    bool         hasMould = false;

    // Mesh-toolpath counterpart of mouldShape: the fully-carved half as a
    // triangle mesh (posNorm + indices, world space). Set on a fixture by
    // GenerateMould only in a mesh scene, and only when the mesh cut yields a
    // non-empty half. Export reads this for STL output; BREP scenes ignore it.
    FileImporter::MeshData mouldMesh;
    bool                   hasMouldMesh = false;

    // Cached BREP shape from import (native for STEP, faceted shell/solid
    // for mesh formats). Populated at import time so boolean operations and
    // export don't have to re-read the source file.
    TopoDS_Shape sourceShape;
    bool         hasSourceShape = false;

    // CPU-side geometry for ray casting (position-only, object space)
    std::vector<float>    cpuVerts;    // 3 floats per vertex
    std::vector<uint32_t> cpuIndices;  // triangle indices

    // Per-triangle edge adjacency for face-region growing (Align Face).
    // triNeighbors[t][k] = the triangle that shares edge k of triangle t
    // (where edge k is between local vertex k and (k+1)%3), or -1 if none.
    // Built lazily on first use; persists for the object's lifetime since
    // local mesh topology never changes after import.
    std::vector<std::array<int, 3>> triNeighbors;
    bool                            adjacencyBuilt = false;

    glm::vec3 pos{ 0.0f, 0.0f, 0.0f };
    float     yawDeg = 0.0f;
    float     pitchDeg = 0.0f;
    float     rollDeg = 0.0f;
    float     scale = 1.0f;

    // Optional reflections about the local YZ / XY planes, applied as a
    // negative component in the scale matrix. Used by the grid-pattern
    // tool to mirror clones placed on the opposite side of the world X
    // or Z axis. With both flags set the mesh is reflected through the
    // local Y axis (parity preserved). The lit shader uses the
    // transpose-inverse normal matrix so reflections light correctly,
    // and face culling is off so reversed winding renders fine.
    bool mirrorX = false;
    bool mirrorZ = false;

    glm::mat4 BuildModelMatrix() const
    {
        glm::mat4 T = glm::translate(glm::mat4(1.0f), pos);
        glm::mat4 RY = glm::rotate(glm::mat4(1.0f), glm::radians(yawDeg), glm::vec3(0, 1, 0));
        glm::mat4 RX = glm::rotate(glm::mat4(1.0f), glm::radians(pitchDeg), glm::vec3(1, 0, 0));
        glm::mat4 RZ = glm::rotate(glm::mat4(1.0f), glm::radians(rollDeg), glm::vec3(0, 0, 1));
        // Per-axis scale: uniform `scale`, with optional mirror flipping
        // X and/or Z. Applied at the innermost (local) step so the
        // reflection acts on the un-rotated mesh; the rotation +
        // translation that follow place the mirrored shape into world
        // space.
        const glm::vec3 sv(scale * (mirrorX ? -1.0f : 1.0f),
            scale,
            scale * (mirrorZ ? -1.0f : 1.0f));
        glm::mat4 S = glm::scale(glm::mat4(1.0f), sv);
        return T * RY * RX * RZ * S;
    }
};

// ---------------------------------------------------------------------------
// InsertFeature — one insert: an imported body whose placement is driven
// entirely by a parent SceneObject plus a local offset / rotation.
//
// Inserts deliberately do NOT live in m_objects:
//   * they never enter the picking FBO, so the model tools (Select / Move /
//     Rotate / Scale / Pattern) can't grab one. An insert moves because its
//     parent moved, or (later) because the Edit Insert tool moved it — never
//     because someone dragged it directly.
//   * their own list makes "Clear all" a single sweep and keeps the object
//     list meaning "bodies that get subtracted to form the cavity".
//
// `body` reuses SceneObject wholesale for the three things an insert needs:
// its GPU mesh (draw), cpuVerts / cpuIndices (the Remove ray-cast), and
// sourceShape (the eventual mould cut). Its POSE FIELDS — pos / yaw / pitch /
// roll / scale / mirrorX / mirrorZ — are unused and must stay that way:
// an insert's placement lives in `worldMatrix`. Composing the parent's
// rotation with the local rotation can't be expressed as a single Euler
// triple without a lossy decomposition, so the resolved matrix is stored
// directly and body.BuildModelMatrix() is never called on an insert.
//
// Parent inheritance is ROTATION + TRANSLATION ONLY. Parent scale and the
// mirrorX / mirrorZ pattern flags are deliberately dropped, so an insert
// keeps its true manufactured size regardless of what the part it sits in is
// scaled to — a brass threaded boss doesn't grow because someone scaled the
// housing. This is the one place inserts diverge from how VentInstance and
// GateFeature parent (those ride the parent's full model matrix).
// ---------------------------------------------------------------------------
struct InsertFeature
{
    SceneObject body;

    // Parent-object association, indexing GLCanvas::m_objects. Unlike
    // VentInstance an insert is ALWAYS parented — placement requires a parent
    // pick — so -1 only appears on a half-built instance. Kept in step with
    // m_objects by the Delete-key reindex block; an insert whose parent is
    // deleted is deleted with it.
    int       parentIndex = -1;
    glm::vec3 localOffset{ 0.0f };   // parent-space offset (mm)
    glm::vec3 localRotDeg{ 0.0f };   // parent-space rotation (deg), YXZ order
    float     localScale = 1.0f;     // UNIFORM scale, authored in the Edit dialog

    // Stable identity, assigned once at placement / clone from m_nextInsertId and
    // never reused. The Edit dialog references an insert by id, not index, so it
    // survives the index shifts a remove causes; a lookup miss means the insert
    // is gone and the dialog closes. -1 only on a half-built instance.
    int       id = -1;

    // Resolved world transform, rebuilt by GLCanvas::ReanchorInsert:
    //   T(parent.pos)*R(parent yaw/pitch/roll)*T(localOffset)*R(localRotDeg)*S(localScale)
    // Rotation + UNIFORM scale + translation only — no parent scale/mirror, and
    // localScale is uniform, so this stays representable as a gp_Trsf for the OCC
    // cut (gp_Trsf can't hold a non-uniform scale). The uniform scale is also why
    // RemoveInsertAtMouse can still compare ray parameters across inserts: for a
    // world ray dir D, M*(inv(M)*D)==D, so the hit t is world-space t regardless
    // of the scale baked into M.
    glm::mat4 worldMatrix{ 1.0f };

    void Destroy() { body.mesh.Destroy(); }
};

// PathEditTool (the EditVent sub-tool enum) is declared in MainFrame.h next to
// TransformMode so the lightweight VentEditToolbar header can use it without
// pulling in this heavy canvas header.

class GLCanvas : public wxGLCanvas
{
public:
    GLCanvas(wxWindow* parent);
    ~GLCanvas() override;

    // Imports any supported format (STEP, STL, OBJ) based on file extension.
    // notify: when true (interactive import), a false->true flip of the
    // scene mesh-type flag pops the one-time "switched to mesh toolpath"
    // notice. Project restore passes false so a bulk load stays silent.
    void ImportFile(const std::string& path, bool notify = true);

    // Import a single fixture half. The optional `xform` carries the per-half
    // pose authored in the FixtureEditor and persisted to the .fixture file
    // ([half_a_transform] / [half_b_transform]). It is applied to the new
    // SceneObject before BuildFixturePerimeter runs, so the parting-line
    // perimeter sees the transformed mesh. Defaulting to an identity
    // HalfTransform makes this a pure no-op for callers that don't have
    // pose data — fixtures from older files (no transform sections) load
    // exactly as they did before.
    void ImportFileAsFixture(const std::string& path,
        const HalfTransform& xform = HalfTransform{});

    // Build a procedural (Parametric or Dynamic) fixture's two box halves
    // directly into m_fixtures — the fileless counterpart to
    // ImportFileAsFixture. Clears any existing fixtures first, gives each half
    // a cached OCC blank (sourceShape) + preview mesh, enables perimeter
    // injection, and rebuilds the parting perimeter. For a Dynamic fixture the
    // box is sized to envelope the current scene; for Parametric it is the
    // fixed authored dimensions. Reads def.kind + def.parametric / def.dynamic;
    // a FixtureKind::Library def is ignored (that path uses ImportFileAsFixture).
    void CreateProceduralFixture(const FixtureDefinition& def);

    // Resize the active Dynamic fixture's two halves to the current scene
    // envelope + the stored clearance and rebuild the perimeter. No-op unless a
    // Dynamic fixture is loaded, so it's safe to call unconditionally. Fired
    // internally from NotifySceneMutated (transforms/features), object add /
    // delete / paste, and object drag-release; also called by MainFrame once
    // after a project load restores the scene.
    void RebuildDynamicFixture();

    // Called by MainFrame ribbon buttons
    void SetTransformMode(TransformMode mode);

    // Called by dialogs
    void ApplyRotation(float xDeg, float yDeg, float zDeg);
    void ApplyTranslation(float x, float y, float z);
    void ApplyScale(float factor);
    void CenterSelectedObject();

    // Precision Place — move the current selection to an absolute world XZ
    // position, preserving each member's Y (height) and the selection's
    // internal arrangement. For a single object this is a direct
    // "pos.x = x, pos.z = z"; for a multi-selection the whole group is
    // shifted so its XZ centroid lands on the target (same convention as
    // CenterSelectedObject).
    void MoveSelectionToXZ(float x, float z);

    // Apply grid configuration (shape / size / spacing / major divisions) to
    // the ground-plane grid. Stored and pushed to the GridRenderer on the next
    // paint (once the GL context and grid program are ready), then refreshes.
    void SetGridSettings(const GridSettings& s);

    // Snap a world XZ point to the nearest point of the current grid: the
    // rectangular lattice (multiples of the minor spacing, clamped to the
    // extents), or for a circular grid the ring/spoke lattice plus the centre.
    // Uses the active grid settings. Y is the caller's concern.
    glm::vec2 SnapToGrid(const glm::vec2& xz) const;

    // ---- Precision Place for feature path nodes -----------------------------
    // Only nodes that live on the y=0 parting plane AND do their own free
    // positioning are eligible: vent INTERIOR nodes (the origin snaps to the
    // part silhouette, the endpoint to the fixture perimeter) and runner
    // interior/endpoint nodes (node[0] is pinned to the sprue feed). Gates are
    // excluded — their sub-runner path snaps. Mirrors the object-level
    // GetSelectionCenterXZ / MoveSelectionToXZ pair.
    bool IsEditNodePrecisePlaceable(int idx) const;
    bool GetEditNodeXZ(int idx, float& outX, float& outZ) const;
    void MoveEditNodeToXZ(int idx, float x, float z);

    // Nearest eligible path node to the cursor in the active edit mode, or -1.
    // Used by the double-click shortcut into Precision Place.
    int  PickPrecisePlaceableNode(int mouseX, int mouseY) const;

    // The currently selected path node in the active edit mode, or -1. This is
    // the node last grabbed with the Move tool; it persists after the mouse is
    // released (and is what the enlarged node marker indicates), so the edit
    // toolbar can act on it. Returns -1 when the selection isn't Precision
    // Place-eligible, so callers can use it directly to gate the button.
    int  GetSelectedPlaceableNode() const;

    // Index of the TERMINAL node of the selected feature's path in the active
    // edit mode, or -1 when nothing suitable is selected. Selecting a path
    // makes this its active node: the marker the user visually clicks to pick
    // the feature sits ON the end node, so selecting the path but no node read
    // as nothing having been picked.
    int  EditEndNodeIndex() const;

    // Report the XZ centroid of the current selection (the value the
    // Precision Place dialog pre-fills). Returns false (leaving outputs
    // untouched) when nothing is selected.
    bool GetSelectionCenterXZ(float& outX, float& outZ) const;

    // Circular pattern around the world origin in the XZ plane.
    //   count          - total instances including the original (no-op if <= 1)
    //   overrideRadius - if true, place clones at `radius` instead of the
    //                    original's current XZ distance from the origin
    //   radius         - the override radius, in world units (mm)
    //   rotateCopies   - if true, each clone's local yaw is rotated by its
    //                    angular offset (gear-tooth style — every instance
    //                    faces outward like the original). If false, every
    //                    clone keeps the original's local rotation verbatim.
    // The original keeps its position; (count - 1) clones are placed at
    // equally-spaced angular offsets around the origin.
    void ApplyCircularPattern(int count, bool overrideRadius, float radius,
        bool rotateCopies);

    // Grid pattern in the y=0 plane, centred on the world origin.
    //   numH               - cell count along X (>= 1)
    //   numV               - cell count along Z (>= 1)
    //   mirrorH            - if true, clones whose X coordinate sits on the
    //                        opposite side of x=0 from the original have
    //                        their mesh reflected about the local YZ plane
    //   mirrorV            - same for Z (reflection about local XY plane)
    //   overrideLengthWidth- if true, use `length`/`width` (interpreted as
    //                        full grid extents) instead of deriving from
    //                        the original's (x,z), which is treated as
    //                        half the full grid extent.
    //   length             - full X extent of the grid (mm), override only
    //   width              - full Z extent of the grid (mm), override only
    // The grid spans [-halfX, +halfX] x [-halfZ, +halfZ] in the y=0 plane,
    // with halfX,halfZ derived per above. The original is anchored to the
    // corner cell matching its current XZ-quadrant (and is moved there if
    // override is on or if its position no longer matches the anchor).
    void ApplyGridPattern(int numH, int numV, bool mirrorH, bool mirrorV,
        bool overrideLengthWidth, float length, float width);

    bool HasSelection() const { return !m_selectedIndices.empty(); }
    TransformMode GetTransformMode() const { return m_transformMode; }

    // Build the moulds for every fixture in the scene. Returns true when the
    // generation pipeline ran to completion, false when an up-front validation
    // failed (no fixtures loaded, or no imported objects to subtract). Used by
    // MainFrame to gate the Export button — Export stays disabled until at
    // least one successful run. Per-fixture failures inside the loop don't
    // affect the return: the function still falls through and returns true,
    // matching the existing success-message-box behaviour.
    bool GenerateMould();
    void ExportFixtures(const std::string& pathA, const std::string& pathB);

    // Export just the shot body (see GetLastShotShape/GetLastShotMesh) to a
    // single file: the exact fused BREP as STEP for a BREP scene, or the
    // tessellated shot mesh as STL for a mesh scene (no BREP shot exists in
    // that case — see the "Shot model" section of GenerateMould). No-op with
    // a warning dialog if the last GenerateMould run didn't produce a shot.
    void ExportShotBody(const std::string& path);

    // Write a display mesh (posNorm + indices, already in world space) to a
    // binary STL. Public + static so callers outside the canvas (e.g. the
    // cast-body export in MainFrame) reuse the exact writer the mould-half and
    // shot-body STL exports use. Returns false on empty mesh or any file error.
    static bool WriteMeshToStl(const std::string& path,
        const FileImporter::MeshData& mesh);

    // Write a single OCC solid to a STEP file (AsIs). Public + static so the
    // cast-body export can emit STEP for BREP scenes, mirroring how the shot
    // body / mould halves export. Returns false on a null shape or file error.
    static bool WriteShapeToStep(const std::string& path,
        const TopoDS_Shape& shape);

    // Tessellate an OCC shape into a render-ready MeshData (vertices meshed,
    // per-vertex normals computed, crease-split applied so the interleaved
    // posNorm + indices upload cleanly), with orientation-aware winding.
    // `mesh` is cleared first. When `faceIds` is non-null it is filled with one
    // entry per output triangle: the 1-based index of that triangle's source
    // face in a TopExp::MapShapes(shape, TopAbs_FACE) map (the crease split
    // preserves triangle order, so the map stays aligned with mesh.indices).
    // Static + public (uses no canvas state) so the cast-body BREP path can
    // reuse it to build display meshes from its solids.
    static void TessellateShapeToMesh(const TopoDS_Shape& shape,
        FileImporter::MeshData& mesh,
        std::vector<int>* faceIds = nullptr);

    // The Cast Shot Body as a BREP solid from the most recent GenerateMould
    // (the exact fused shape m_lastCastShotMesh is the tessellation of). Null in
    // a mesh scene or when none was built. Consumed by the cast bases so they
    // can be built as BREP for STEP export.
    const TopoDS_Shape& GetLastCastShotShape() const { return m_lastCastShotShape; }

    // True once the scene holds at least one mesh-format body (STL/OBJ) among
    // the imported objects or inserts — i.e. the scene is on the mesh toolpath.
    // Maintained by RecomputeSceneMeshType at every add/remove/clear. Later
    // stages read this to route GenerateMould, gate exports to STL, and refuse
    // the BREP-only design checks.
    bool IsSceneMeshType() const { return m_sceneIsMesh; }

    // ---- Preview perspective ------------------------------------------------
    // A second GLCanvas instance (hosted by PreviewPanel) is put into preview
    // mode to show the post-cut mould halves on their own. Preview mode strips
    // the canvas down to: grid + the loaded mould halves, with the standard
    // orbit / pan / dolly navigation but no picking, selection, transform
    // modes, feature placement, or keyboard shortcuts. The main canvas is
    // never in preview mode.

    // Switch this canvas into (or out of) preview mode. Idempotent.
    void SetPreviewMode(bool on) { m_previewMode = on; }
    bool IsPreviewMode() const { return m_previewMode; }

    // Append one part to the preview from a world-space mesh (position +
    // normal interleaved, plus indices — exactly the MeshData produced by
    // GenerateMould). The mesh is uploaded to this canvas's own GL context and
    // stored with an identity pose, since the fixture transform is already
    // baked into the world-space vertices. `label` is shown on the part's
    // show/hide toggle (e.g. "Half A", "Shot"). `baseColor` lets the shot
    // model read distinctly from the grey mould halves. Parts start visible.
    // Must be called with this canvas's GL context current — PreviewPanel
    // arranges that.
    void AddPreviewHalf(const FileImporter::MeshData& mesh,
        const std::string& label,
        const glm::vec3& baseColor = glm::vec3(0.80f, 0.80f, 0.85f));

    // Number of preview parts (mould halves + shot) currently loaded.
    int  GetPreviewHalfCount() const { return (int)m_previewHalves.size(); }

    // Label of part `index` (empty string if out of range).
    std::string GetPreviewHalfLabel(int index) const;

    // Show / hide an individual part. Out-of-range indices are ignored.
    void SetPreviewHalfVisible(int index, bool visible);
    bool IsPreviewHalfVisible(int index) const;

    // Drop every loaded preview part (frees their GPU resources). Safe to call
    // with no context current only if nothing has been uploaded yet.
    void ClearPreviewHalves();

    // Drop preview parts from index `keepCount` onward (freeing their GPU
    // resources), keeping the first `keepCount` intact. Lets the preview strip
    // off appended cast bodies before regenerating them without disturbing the
    // mould halves / shot / inserts (whose CPU-side meshes have already been
    // released). keepCount <= 0 clears all; keepCount >= count is a no-op.
    void TruncatePreviewHalves(int keepCount);

    // ---- Design-check debug colouring --------------------------------------
    // One flat-coloured group of facets for the debug overlay: every triangle
    // in `indices` (vertex-index triples into the part's own vertex buffer)
    // draws in `color`. The caller partitions the part's triangles into groups.
    struct ShotDebugGroup
    {
        glm::vec3             color{ 0.5f };
        std::vector<uint32_t> indices;
        bool                  emissive = false;  // draw flat (highlight) vs lit
    };

    // Recolour a preview part's facets using the given groups, for debugging
    // (each group drawn over a dedicated debug VAO that reuses the part's
    // existing vertices). Replaces any previous debug colouring. Used to
    // visualise check categories or, e.g., draft sign across the shot. A group
    // flagged `emissive` draws at full intensity (lighting flattened to its
    // flat colour) so it reads as a highlight; other groups stay shaded by the
    // normal lit pass, preserving the surface's 3D form.
    void SetShotDebugGroups(int halfIndex,
        const std::vector<ShotDebugGroup>& groups);

    // Turn debug colouring off — the shot returns to its normal single colour.
    void ClearShotDebugColoring();

    // ---- Design-check debug rays -------------------------------------------
    // Upload accessibility-ray debug geometry for the preview: `rayLineVerts`
    // is GL_LINES vertex pairs (world space) for the ray segments, and
    // `contactVerts` is GL_POINTS world positions for the contact markers.
    // Rendered with the flat (unlit) shader. Replaces any previous ray geometry.
    void SetShotDebugRays(const std::vector<glm::vec3>& rayLineVerts,
        const std::vector<glm::vec3>& contactVerts);

    // Toggle visibility of the ray segments / contact markers independently.
    void ShowShotDebugRays(bool on);
    void ShowShotDebugContacts(bool on);

    // Forget ray geometry and hide both overlays.
    void ClearShotDebugRays();

    // ---- Design-check debug solid ------------------------------------------
    // Upload a free-standing solid (e.g. the interference region from the
    // separation test) and show it in the preview, lit, in `color`. Replaces
    // any previous debug solid. Rendered at identity pose (world space).
    void SetShotDebugSolid(const TopoDS_Shape& shape, const glm::vec3& color);
    void ShowShotDebugSolid(bool on);
    void ClearShotDebugSolid();

    // Read-only access to the meshes produced by the most recent successful
    // GenerateMould run, one per fixture, in fixture order. World-space,
    // interleaved position+normal with indices. PreviewPanel consumes these
    // to populate a fresh preview window. Cleared at the start of every
    // GenerateMould call.
    const std::vector<FileImporter::MeshData>& GetLastMouldMeshes() const
    {
        return m_lastMouldMeshes;
    }

    // Display meshes of the inserts from the most recent successful
    // GenerateMould (world-space, one per insert, unscaled). PreviewPanel shows
    // these as a distinct yellow category behind a single show/hide checkbox.
    const std::vector<FileImporter::MeshData>& GetLastInsertMeshes() const
    {
        return m_lastInsertMeshes;
    }

    // The "shot" model from the most recent successful GenerateMould: the
    // boolean union of every imported object and the feed-system features
    // (sprue, runners, gates and their sub-parts) — i.e. all placed features
    // except vents and ejectors. World-space, interleaved position+normal
    // with indices. This is the material body that fills the cavity; it is
    // also the geometry that downstream simulation will operate on. Valid only
    // when HasLastShotMesh() returns true (the union can legitimately be empty
    // when no objects/feed features exist or the fuse failed).
    bool HasLastShotMesh() const { return m_hasLastShotMesh; }
    const FileImporter::MeshData& GetLastShotMesh() const
    {
        return m_lastShotMesh;
    }

    // Volume of the shot solid from the most recent successful GenerateMould,
    // in cubic millimetres (the scene's modelling unit). Computed from the
    // fused BREP — overlaps between fused primitives are counted once — so it
    // is the true material volume, not a mesh approximation. Zero when no shot
    // was built (HasLastShotMesh() == false).
    double GetLastShotVolumeMm3() const { return m_lastShotVolumeMm3; }

    // The shot solid as a BREP, for design-check analysis at the face level.
    // Valid only when HasLastShotMesh() is true.
    const TopoDS_Shape& GetLastShotShape() const { return m_lastShotShape; }

    // The "Cast Shot Body" from the most recent GenerateMould: the standard
    // shot PLUS the features normally left out of it — vents, inserts (grown by
    // the insert Cut scale), and ejector pins — fused into one solid. Not shown
    // to the user; the cast-mould bases consume it (each base fuses in a y-split
    // half). Valid only when HasLastCastShotMesh() is true.
    bool HasLastCastShotMesh() const { return m_hasLastCastShotMesh; }
    const FileImporter::MeshData& GetLastCastShotMesh() const
    {
        return m_lastCastShotMesh;
    }

    // Per display-triangle source-face index (1-based, into a
    // TopExp::MapShapes(shot, TopAbs_FACE) map of GetLastShotShape()). One
    // entry per triangle of GetLastShotMesh(); lets a face-level result be
    // mapped back to the shot's display triangles for colouring.
    const std::vector<int>& GetLastShotFaceIds() const { return m_lastShotFaceIds; }

    // The post-cut mould-half solids (BREP) from the most recent successful
    // GenerateMould, in fixture order. Used by the separation-based
    // demoldability check (translate each half off the shot and test for
    // interference). Empty when no mould was generated.
    const std::vector<TopoDS_Shape>& GetLastHalfShapes() const
    {
        return m_lastHalfShapes;
    }

    // Scene-mutation callback. MainFrame registers a callback that
    // invalidates the Export button when anything that would stale a
    // previously generated mould happens — transforms, feature place /
    // remove, sprue placement, etc. Fired synchronously from every
    // mutating method on this class that I've identified; project-
    // level changes (import, fixture swap, project load) are handled
    // on the MainFrame side directly since some of them route around
    // canvas methods entirely.
    //
    // Known gap as of this iteration: Edit* modes commit their drag
    // updates via OnPaint's m_editNeedsUpdate path, which doesn't
    // currently emit through here. Tracked as a follow-up.
    void SetOnSceneMutated(std::function<void()> cb)
    {
        m_onSceneMutated = std::move(cb);
    }

    // ---- Part 5: complex vent-path authoring hooks -------------------------
    // Fired whenever the EditVent selection or path-edit state changes (a vent
    // is picked / deselected, a Simple<->Complex conversion happens, the
    // smooth flag flips, or a node is added / removed). The MainFrame uses it
    // to reconfigure and reposition the floating VentEditToolbar.
    void SetOnPathEditChanged(std::function<void()> cb)
    {
        m_onPathEditChanged = std::move(cb);
    }

    // Register the floating toolbar window (a child of this canvas). The canvas
    // treats it as an opaque wxWindow* — it only needs to reposition it on
    // resize so it stays pinned to the top-centre of the viewport.
    void SetPathToolbar(wxWindow* w) { m_pathToolbar = w; RepositionPathToolbar(); }

    // The Edit Sprue toolbar rides the same top-centre slot as the path
    // toolbar (they never show together), but is a distinct window, so it gets
    // its own pointer. RepositionPathToolbar pins both.
    void SetSprueToolbar(wxWindow* w) { m_sprueToolbar = w; RepositionPathToolbar(); }

    // Register the bottom-centre hint overlay ("toast"). Same arrangement as
    // the path toolbar - a SIBLING of the canvas raised above it, not a child,
    // since SwapBuffers can overdraw a true child of a wxGLCanvas. The canvas
    // only pins its position; the owner creates it and decides what it says
    // and when it is visible.
    void SetCanvasToast(wxWindow* w) { m_canvasToast = w; RepositionCanvasToast(); }

    // Re-pin the toast to the bottom-centre of the viewport. PUBLIC (unlike its
    // RepositionPathToolbar twin, which only the canvas calls): the toast sizes
    // itself to its message, so the owner has to re-centre it after every text
    // change, not just on canvas resize.
    void RepositionCanvasToast();

    // State queried by the floating toolbar.
    bool         IsEditingVent()       const { return m_transformMode == TransformMode::EditVent; }
    bool         HasEditVentSelected() const
    {
        return m_transformMode == TransformMode::EditVent &&
            m_editFeatureIndex >= 0 && m_editFeatureIndex < (int)m_vents.size();
    }
    bool         IsEditVentComplex()   const;
    bool         IsEditVentSmooth()    const;
    int          EditVentNodeCount()   const;
    PathEditTool GetPathEditTool()     const { return m_pathEditTool; }

    // Commands invoked by the floating toolbar.
    void SetPathEditTool(PathEditTool t);
    void ConvertEditVentToComplex();   // seed nodes from the Simple path; no-op if already Complex
    void ConvertEditVentToSimple();    // drop nodes, re-derive the Simple path
    void SetEditVentSmooth(bool smooth);

    // Runner-path authoring (Part 7 / R5) — parallels the vent API above and is
    // driven by the SAME shared floating toolbar while in EditRunner mode. The
    // deltas vs vents: node[0] is pinned to the sprue feed point (only the free
    // endpoint moves) and the endpoint is NOT snapped to the perimeter.
    bool         IsEditingRunner()       const { return m_transformMode == TransformMode::EditRunner; }
    bool         HasEditRunnerSelected() const
    {
        return m_transformMode == TransformMode::EditRunner &&
            m_editFeatureIndex >= 0 && m_editFeatureIndex < (int)m_runners.size();
    }
    bool         IsEditRunnerComplex()   const;
    bool         IsEditRunnerSmooth()    const;
    int          EditRunnerNodeCount()   const;

    void ConvertEditRunnerToComplex();  // seed [feed point, endpoint]; no-op if already Complex
    void ConvertEditRunnerToSimple();   // drop nodes, collapse to the straight runner
    void SetEditRunnerSmooth(bool smooth);

    // ---- Gate SUB-RUNNER complex-path editing (G5) -------------------------
    // Driven by the SAME shared floating toolbar while in EditGate mode. The
    // gate FRUSTUM stays a straight tapered cone from the card fields; only the
    // sub-runner gets a complex route. node[0] is pinned to the gate origin
    // (gf.point.worldPos); the endpoint (nodes.back()) is the feed attach point,
    // freely authored when Complex (it does not chase a moving feed).
    bool         IsEditingGate()       const { return m_transformMode == TransformMode::EditGate; }
    bool         HasEditGateSelected() const
    {
        return m_transformMode == TransformMode::EditGate &&
            m_editFeatureIndex >= 0 && m_editFeatureIndex < (int)m_gates.size();
    }
    bool         IsEditGateComplex()   const;
    bool         IsEditGateSmooth()    const;
    int          EditGateNodeCount()   const;

    void ConvertEditGateToComplex();  // seed [gate origin, feed attach]; no-op if already Complex
    void ConvertEditGateToSimple();   // drop nodes, collapse to the straight sub-runner
    void SetEditGateSmooth(bool smooth);

    // ---- Sprue editing (Edit Sprue environment) ---------------------------
    // Unlike the path-edit modes above, the sprue has no node model — its edit
    // environment offers a Move sub-tool (drag a RADIAL sprue's endpoint on the
    // parting plane) and a Select Injection Point sub-tool (re-pick the feeding
    // injection point). Driven by the floating SprueEditToolbar. Axial sprues
    // are NOT movable (moving the endpoint would compromise demolding), so Move
    // is gated on IsActiveSprueRadial().
    bool IsEditingSprue() const { return m_transformMode == TransformMode::EditSprue; }
    bool HasSprueForEdit() const { return m_sprue.hasPoint; }
    bool IsActiveSprueRadial() const
    {
        return m_hasActiveInjectionPoint &&
            m_activeInjectionPoint.type == InjectionType::Radial;
    }
    // The Select Injection Point sub-tool is worth offering only when the
    // fixture actually gives a choice (>1 point); with a single point there is
    // nothing to switch to.
    bool HasInjectionChoices() const { return m_injectionPoints.size() > 1; }

    // "Fixture Perimeter" injection (see FixtureDefinition::allowPerimeterInjection):
    // the fixture permits placing the sprue's injection point anywhere on the
    // perimeter. Set from the fixture on load.
    void SetAllowPerimeterInjection(bool b) { m_allowPerimeterInjection = b; }
    bool AllowsPerimeterInjection() const { return m_allowPerimeterInjection; }
    // True when the ACTIVE injection point is a perimeter-placed one — its
    // location is draggable along the perimeter (vs a fixed point, whose
    // Move drags the sprue endpoint instead).
    bool IsActivePerimeterInjection() const
    {
        return m_hasActiveInjectionPoint && m_activeInjectionPoint.perimeter;
    }

    SprueEditTool GetSprueEditTool() const { return m_sprueEditTool; }
    void SetSprueEditTool(SprueEditTool t);

    // Drag the radial sprue endpoint to the parting-plane point under the mouse
    // and rebuild the sprue (and dependent runner/gate) geometry. No-op for an
    // axial sprue or when no sprue is placed. Does not fire the scene-mutation
    // hook itself — the mouse-up in EditSprue does, once per drag gesture.
    void MoveSprueEndpoint(int mouseX, int mouseY);

    // Drag a PERIMETER injection point along the fixture perimeter (snapping to
    // it) and re-place the sprue from the new location. No-op unless the active
    // injection point is a perimeter one. Like MoveSprueEndpoint, leaves the
    // scene-mutation notify to the mouse-up.
    void MoveSprueInjectionPoint(int mouseX, int mouseY);

    void ClearFixtures();

    // Vent point placement
    const std::vector<VentInstance>& GetVents() const { return m_vents; }
    void ClearVentPoints();

    // Sprue placement
    void SetActiveInjectionPoint(const InjectionPoint& ip);
    void SetInjectionPoints(const std::vector<InjectionPoint>& pts);
    void PlaceSprue();
    void ClearSprue();
    bool IsDirectInjection() const { return m_sprue.isDirectInjection; }

    // Point where the sprue path crosses the y=0 parting plane
    bool              HasSpruePartingPoint() const { return m_sprue.hasPartingPoint; }
    const glm::vec3& GetSpruePartingPoint() const { return m_sprue.partingPos; }

    // Runner placement
    const std::vector<RunnerFeature>& GetRunners() const { return m_runners; }
    void ClearRunnerPoints();

    // Gate placement
    const std::vector<GateFeature>& GetGates() const { return m_gates; }
    void ClearGatePoints();

    // Ejector placement
    const std::vector<EjectorFeature>& GetEjectors() const { return m_ejectors; }
    void ClearEjectors();
    // Rebuild every ejector's preview cylinder. Called after place / clear /
    // any operation that changes the ejector list. Reads diameter and
    // length from the MainFrame UI at call time, same convention as
    // RebuildGateSolids — so changing the dimension fields and placing a
    // new ejector picks up fresh values, but existing ejectors keep
    // whatever dimensions they were built with.
    void RebuildEjectorSolids();

    // Indexer placement (Aug 2026). Always on the parting plane (y=0), picked
    // via RayCastToPartingPlane — no multi-source snapping like Ejector.
    // Same "geometry TBD" maturity: a preview sphere only, no mould-half /
    // cast-shot fuse yet. See IndexerFeature in MouldFeature.h.
    const std::vector<IndexerFeature>& GetIndexers() const { return m_indexers; }
    void ClearIndexers();
    // Rebuild every indexer's preview sphere. Reads Radius from the
    // MainFrame UI at call time, same convention as RebuildEjectorSolids.
    void RebuildIndexerSolids();

    // ---- Insert placement ---------------------------------------------------
    // See InsertFeature above for the ownership / inheritance model.
    const std::vector<InsertFeature>& GetInserts() const { return m_inserts; }
    void ClearInserts();

    // Import `path` and attach it to m_objects[parentIdx] as an insert whose
    // local origin lands on the parent's origin (localOffset / localRotDeg
    // both zero). Captures the card's Cut scale. Returns false — after the
    // usual import error box — on a stale parent index or a failed import.
    bool PlaceInsertOnObject(int parentIdx, const std::string& path);

    // Index of the single selected object, or -1 when nothing is selected or
    // more than one is. Drives "use the current selection as the parent" in
    // MainFrame::OnPlaceInsert; a multi-selection returns -1 rather than
    // guessing which member to parent to.
    int  GetSingleSelectedObject() const;

    // ---- Insert editing (used by the modeless Edit-Insert dialog) ----------
    // Pick the insert whose body the mouse ray hits first, or -1 on a miss.
    // Same hit-test as RemoveInsertAtMouse (which now shares it); EditInsert
    // mode uses it to choose which insert the dialog targets. Non-const because
    // BuildMouseRay (shared with every other picker) is non-const.
    int  PickInsertAtMouse(int mouseX, int mouseY);

    // id <-> index resolution. Index is only valid until the next structural
    // change to m_inserts; id is stable, so the dialog holds the id.
    int  InsertIndexFromId(int id) const;
    int  InsertIdAtIndex(int index) const;

    // Read / write one insert's local transform by id. Get returns false (and
    // leaves the outs untouched) when the id is gone — the dialog treats that
    // as "target removed" and closes. Set reanchors, redraws and marks the
    // scene mutated; scale is clamped to a small positive minimum so a zero or
    // negative value can't produce a degenerate matrix.
    bool GetInsertTransformById(int id, glm::vec3& offset, glm::vec3& rotDeg,
        float& scale) const;
    bool SetInsertTransformById(int id, const glm::vec3& offset,
        const glm::vec3& rotDeg, float scale);

    // Remove individual features by clicking their marker
    void RemoveVentAtMouse(int mouseX, int mouseY);
    void RemoveRunnerAtMouse(int mouseX, int mouseY);
    void RemoveGateAtMouse(int mouseX, int mouseY);
    void RemoveSprueAtMouse(int mouseX, int mouseY);
    void RemoveEjectorAtMouse(int mouseX, int mouseY);
    void RemoveIndexerAtMouse(int mouseX, int mouseY);

    // Unlike the other Remove*AtMouse helpers this hit-tests the insert's MESH
    // rather than a marker sphere — an insert is a body, so clicking anywhere
    // on it removes it.
    void RemoveInsertAtMouse(int mouseX, int mouseY);

    // ---- Project save/load support -----------------------------------------

    // Read-only accessors for serialization
    const std::vector<SceneObject>& GetObjects()  const { return m_objects; }
    const std::vector<SceneObject>& GetFixtures() const { return m_fixtures; }
    const SprueFeature& GetSprue()    const { return m_sprue; }
    bool  HasActiveInjectionPoint()               const { return m_hasActiveInjectionPoint; }
    const InjectionPoint& GetActiveInjectionPoint() const { return m_activeInjectionPoint; }

    // Restore helpers — programmatic placement from saved data (no mouse/ray cast)
    void RestoreObject(const std::string& path, const glm::vec3& pos,
        float yaw, float pitch, float roll, float scale,
        bool mirrorX, bool mirrorZ);

    // Restore an insert during project load: re-import the body from `path`
    // (like RestoreObject) and parent it to object[parentIndex] with the saved
    // local transform. Skips silently if the parent index is out of range (its
    // object failed to restore) or the body import fails. Does not mark the
    // scene mutated — this is load, not an edit.
    void RestoreInsert(const std::string& path, int parentIndex,
        const glm::vec3& localOffset, const glm::vec3& localRotDeg,
        float localScale);

    void RestoreSprue(const ProjectSprueData& data);

    void RestoreRunner(const glm::vec3& point);

    // Restore a runner whose path was authored as a complex (multi-node) path.
    // Like RestoreVentComplex, the path is rebuilt verbatim from `nodes` (>= 2,
    // on the parting plane) and `smooth` rather than re-derived; `point` is the
    // runner endpoint (== nodes.back()). Solids are built by the following
    // RebuildRunnerSolids (ComputeRunnerPath preserves the authored path).
    void RestoreRunnerComplex(const glm::vec3& point,
        const std::vector<PathNode>& nodes, bool smooth);

    void RestoreGate(const glm::vec3& pos, const glm::vec3& normal,
        int parentIndex = -1,
        const glm::vec3& localPos = glm::vec3(0.0f),
        const glm::vec3& localNormal = glm::vec3(0.0f, 0.0f, 1.0f));

    // Restore a gate whose SUB-RUNNER was authored as a complex (multi-node)
    // path. Like RestoreGate for the placement + parent fields, but the
    // sub-runner path is rebuilt verbatim from `nodes` (>= 2, on the parting
    // plane; node[0] the gate origin, nodes.back() the feed attach) and `smooth`
    // rather than re-derived. The gate frustum still comes from the card fields.
    void RestoreGateComplex(const glm::vec3& pos, const glm::vec3& normal,
        const std::vector<PathNode>& nodes, bool smooth,
        int parentIndex = -1,
        const glm::vec3& localPos = glm::vec3(0.0f),
        const glm::vec3& localNormal = glm::vec3(0.0f, 0.0f, 1.0f));

    void RestoreVent(const glm::vec3& pos, const glm::vec3& normal,
        float ventWidth, float ventLength,
        float overrunStart, float overrunEnd,
        int parentIndex = -1,
        const glm::vec3& localPos = glm::vec3(0.0f),
        const glm::vec3& localNormal = glm::vec3(0.0f, 0.0f, 1.0f));

    // Restore a vent whose path was authored as a complex (multi-node) path.
    // Unlike RestoreVent, the path is NOT re-derived — it is rebuilt verbatim
    // from `nodes` (>= 2, on the parting plane) and `smooth`. pos/normal are
    // the vent origin (matches nodes.front()).
    void RestoreVentComplex(const glm::vec3& pos, const glm::vec3& normal,
        const std::vector<PathNode>& nodes, bool smooth,
        float ventWidth, float ventLength,
        float overrunStart, float overrunEnd,
        int parentIndex = -1,
        const glm::vec3& localPos = glm::vec3(0.0f),
        const glm::vec3& localNormal = glm::vec3(0.0f, 0.0f, 1.0f));

    // Restore an ejector during project load. No batch rebuild is performed
    // here — the caller is expected to invoke RebuildAllFeatures() once at
    // the end of the load to materialise GPU resources for every restored
    // feature in one pass.
    void RestoreEjector(const glm::vec3& point);

    // Restore an indexer during project load. Same batching convention as
    // RestoreEjector — no rebuild here, RebuildAllFeatures() at the end.
    void RestoreIndexer(const glm::vec3& point);

    // Rebuild all derived geometry after a batch restore (call once at end)
    void RebuildAllFeatures();

    // Clear everything (fixtures, objects, features) for a fresh load
    void ClearAll();

private:
    void OnPaint(wxPaintEvent& evt);
    void OnResize(wxSizeEvent& evt);
    void OnMouse(wxMouseEvent& evt);
    void OnMouseDClick(wxMouseEvent& evt);
    void OnMouseWheel(wxMouseEvent& evt);
    void OnKeyDown(wxKeyEvent& evt);

    // Ctrl release ends grid snapping; the ghosts/node drags read the key
    // state in the paint pass, so repaint to drop back to the free position.
    void OnKeyUp(wxKeyEvent& evt);

    // Preview-mode render path: grid + loaded mould halves only, all opaque,
    // honouring each half's visibility flag. Called from OnPaint after the
    // clear + camera setup when m_previewMode is true; the normal scene/
    // feature passes are skipped entirely.
    void RenderPreview(const glm::mat4& view, const glm::mat4& proj,
        const glm::vec3& camPos);

    // Sets every shared lit-shader uniform (key + camera-relative fill +
    // hemisphere ambient + default coefficients) in one place. Call with
    // m_program bound; per-pass coefficient overrides go after it. Keeps the
    // ~18 lit draw sites from drifting apart.
    void ApplyLitLighting(const glm::mat4& view, const glm::vec3& camPos);

    // Build the "shot" solid: the boolean union of every imported object
    // (transformed to world space) and the feed-system features — sprue +
    // cold slug, runners + cold plugs, gates + sub-runners — but NOT vents or
    // ejectors. All contributing primitives are constructed in world space
    // with the same geometry the cut loop uses, then fused pairwise. Returns
    // true and fills `out` when a non-null union results; returns false when
    // nothing contributed or the fuse failed outright. Read by GenerateMould.
    bool BuildShotModel(TopoDS_Shape& out);

    // Build the "Cast Shot Body": BuildShotModel's shot fused with the features
    // deliberately excluded from it — vents (their cut channels), inserts grown
    // by the insert Cut scale, and ejector pins (straight cylinders down -Y).
    // World-space BREP, fused pairwise (disjoint pieces are fine). Returns true
    // and fills `out` when at least one piece contributed; false when the scene
    // had nothing to build. Consumed by GenerateMould to seed m_lastCastShotMesh.
    bool BuildCastShotModel(TopoDS_Shape& out);

    // Mesh-toolpath shot: union the STEP-object + feed-system shot (from
    // BuildShotModel, tessellated) with the native mesh objects, then subtract
    // the mesh inserts (unscaled), producing a single mesh shot body and its
    // volume in mm^3. Returns false if there's nothing to build. Used only in
    // mesh scenes (the BREP shot has no mesh objects in it).
    bool BuildMeshShotModel(MeshBoolean::Mesh& outMesh, double& outVolumeMm3);

    // Mesh-scene counterpart to BuildCastShotModel: the augmented shot (standard
    // mesh shot + vents + enlarged inserts + ejector pins) as a single boolean
    // mesh, for the cast-mould bases in a mesh (STL/OBJ) scene. BuildCastShotModel
    // is BREP-only and yields nothing here, which is why a mesh scene's Cast Shot
    // Body used to be empty. Returns false when there's nothing to build.
    bool BuildMeshCastShotModel(MeshBoolean::Mesh& out);

    // Build the world-space solid one insert removes: its body scaled about the
    // local origin by `scalePct` (1.0 == exact body), then placed by the
    // insert's worldMatrix. GenerateMould passes the card's Cut scale for the
    // mould-half cut; BuildShotModel passes 1.0 for the shot void. Returns
    // false (leaving `out` untouched) on a missing BREP or degenerate scale.
    bool BuildInsertCutSolid(const InsertFeature& in, float scalePct,
        TopoDS_Shape& out) const;

    // Post-cut orphaned-volume resolution, run by GenerateMould between the
    // cut phase and the tessellation phase (see the .cpp for the full
    // contract). For each half it splits the fully-cut blank into connected
    // solids and classifies them: a "parent" reaching the mould's OUTER face
    // (the y-plane furthest from the origin), and "orphans" that don't. An
    // orphan touching the OTHER half's parent is fused into that half (it
    // demoulds with it); an orphan touching nothing is a true orphan. On any
    // true orphan the user is prompted to reconfigure (abort) or delete the
    // segments. Returns false only when the user chooses to reconfigure;
    // otherwise mutates halfResults in place to the resolved half shapes and
    // returns true. Two-part moulds only (halfResults / halfValid are indexed
    // by fixture; "the other half" is the other valid entry).
    bool ResolveOrphanVolumes(std::vector<TopoDS_Shape>& halfResults,
        std::vector<bool>& halfValid);

    // Mesh-scene counterpart to ResolveOrphanVolumes, run by GenerateMould after
    // the Manifold carve (which can sever a lump the BREP-stage pass never saw,
    // since that pass runs on the pre-carve BREP result). Same policy: each
    // carved half mesh is split into connected components; the component
    // reaching the mould's OUTER face is the parent, the rest are orphans. An
    // orphan is fused into the OTHER half when translating it by the tolerance
    // toward the parting plane makes it intersect that half's parent (the
    // agreed mesh contact test); otherwise it is a true orphan. On any true
    // orphan the user is prompted to reconfigure (abort) or delete the
    // segments. Returns false only on reconfigure; otherwise mutates meshHalves
    // in place to the resolved half meshes and returns true. Two-part moulds
    // only (indexed by fixture; "the other half" is the other valid entry).
    bool ResolveMeshOrphanVolumes(std::vector<MeshBoolean::Mesh>& meshHalves,
        std::vector<bool>& meshValid);

    // Parting Behavior: nearly-orphaned region combine (BREP scenes). For each
    // BREP object, builds the convex-hull envelope, finds hull-cavity solids
    // that straddle the parting plane (a flat y=0 split would divide them
    // awkwardly), and for each one prompts the user to combine it wholly into
    // the top or bottom half (or keep the y=0 split). "Combine" cuts the region
    // out of one half and fuses it into the other. Runs on the post-cut BREP
    // halves, before the orphan resolver. Gated by the Parting Behavior menu
    // toggle at the call site. Two-part moulds only. Mutates halfResults in
    // place; never aborts generation (worst case: every region kept at y=0).
    void ResolveNearlyOrphanRegions(std::vector<TopoDS_Shape>& halfResults,
        std::vector<bool>& halfValid);

    // Mesh-scene counterpart to ResolveNearlyOrphanRegions, run in phase 3b
    // before the mesh orphan resolver. Same policy in the mesh (Manifold)
    // domain: per mesh object, convex-hull envelope, hull-minus-part cavities,
    // straddling components filtered by the minimum-region-volume setting, a
    // per-region prompt, and transfer via Intersection / Difference / Union.
    // Mutates meshHalves in place; gated by the Parting Behavior toggle at the
    // call site. Two-part moulds only.
    void ResolveMeshNearlyOrphanRegions(std::vector<MeshBoolean::Mesh>& meshHalves,
        std::vector<bool>& meshValid);

    void InitGLOnce();
    void DestroyGL();

    void UploadMeshToGPU(const FileImporter::MeshData& mesh, SceneObject& obj);

    // Shared import core behind ImportFile and PlaceInsertOnObject: runs
    // FileImporter, computes normals, splits by crease angle, snapshots the
    // pre-split geometry for CPU ray casting, caches the BREP shape and
    // uploads to the GPU — all into `out`. `title` labels the progress dialog
    // ("Importing File" / "Importing Insert"). Returns false if the import
    // failed, having already shown the error; `out` is untouched in that case.
    // Warns on a mesh that couldn't be sewn closed, same as before.
    bool ImportBodyInto(const std::string& path, SceneObject& out,
        const wxString& title);

    // Re-resolve one insert's worldMatrix from its parent's current pose.
    // No-op when parentIndex is out of range. Called on placement, on any
    // transform of the parent (via ReanchorFeaturesForObjects) and from
    // RebuildAllFeatures.
    void ReanchorInsert(InsertFeature& in);

    // Push a cloned insert parented to `cloneIdx`, rebuilding its GPU mesh from
    // cached CPU geometry (no source re-read) and resolving its world
    // transform. Shared by ApplyCircularPattern / ApplyGridPattern so an insert
    // patterns identically to a placed one.
    void CloneInsertOnto(int cloneIdx,
        const glm::vec3& localOffset, const glm::vec3& localRotDeg,
        float localScale,
        const std::vector<float>& cpuVerts,
        const std::vector<uint32_t>& cpuIndices,
        const TopoDS_Shape& sourceShape, bool hasSourceShape,
        const std::string& sourcePath);

    // Fire the frame's insert-editor validator after a STRUCTURAL change to
    // m_inserts (add/remove/clear) so a dialog whose target vanished closes.
    // No-op when no frame / no dialog. Transform-only edits don't call this.
    void NotifyInsertsChanged();

    void EnsurePickFBO(int w, int h);
    void DestroyPickFBO();

    int  PickObjectAt(int mouseX, int mouseY);
    void RenderPickPass_NoRead(int w, int h);

    // Vent point ray casting
    bool RayCastObjects(int mouseX, int mouseY,
        glm::vec3& outPos, glm::vec3& outNormal);

    // Parting-plane snap: finds closest point on the mesh's y=0 intersection.
    // outObjectIndex (optional): if non-null and the cast succeeds, receives
    // the index into m_objects of the object whose parting segment won the
    // snap. -1 means no nearby object (cast still fails as before).
    bool RayCastParting(int mouseX, int mouseY,
        glm::vec3& outPos, glm::vec3& outNormal,
        int* outObjectIndex = nullptr);

    // Simple ray–plane intersection with y=0 (no mesh snapping)
    bool RayCastToPartingPlane(int mouseX, int mouseY, glm::vec3& outPos);

    // Snap-pick for ejector placement. Considers four candidate sources:
    //   1. Sprue path's intersection with y=0 (m_sprue.partingPos),
    //   2. Any runner segment (sprue parting pos -> runner pt, on y=0),
    //   3. Any gate segment (gate worldPos -> gate.pathEnd),
    //   4. Any object face (full mesh ray-cast).
    // Path candidates win when within kEjectorSnapRadiusPx screen-space
    // pixels of the cursor; otherwise falls through to the face hit.
    // Returns false if nothing is in range. See implementation for the
    // ranking rationale.
    bool RayCastEjectorSnap(int mouseX, int mouseY, glm::vec3& outPos);

    // Ctrl-held ejector placement: XZ snapped to the nearest grid point, Y
    // taken from the shell (topmost object surface) directly above that point
    // rather than snapped — the grid is an XZ lattice, so it has no say in Y.
    // Returns false when no shell lies over the snapped point (nothing to
    // eject from), matching RayCastEjectorSnap's silent-miss behaviour.
    bool RayCastEjectorGridSnap(int mouseX, int mouseY, glm::vec3& outPos);

    // Sticky placement helpers — re-derive a parented vent's / gate's
    // world-space data from its parent object's current transform plus the
    // stored local-space placement, then rebuild GPU geometry. No-op when
    // parentIndex is out of range. ReanchorFeaturesForObjects walks both
    // feature lists once and re-anchors anything whose parent is in the
    // supplied set; called from Apply* transforms, drag-translate, and
    // patterning so features track their parent objects automatically.
    void ReanchorVent(VentInstance& vi);
    void ReanchorGate(GateFeature& gf);
    void ReanchorFeaturesForObjects(const std::vector<int>& objIndices);

    // Vent path computation and GPU upload
    VentPath         ComputeVentPath(const VentPoint& vp);
    void             RebuildPathVBO();

    // ---- Part 5: complex vent-path authoring internals ---------------------
    // Rebuild the currently edited vent's cross-section, preview solid and the
    // start/end mirror from its (already mutated) path.nodes, reading width /
    // length / overrun from the MainFrame UI. Recomputes auto handles first
    // when the path is smooth. Refreshes path + cross-section VBOs.
    void RebuildEditVentGeometry();

    // Closest point (XZ, y=0) on the fixture perimeter polygon to p. Returns p
    // unchanged when no perimeter is available.
    glm::vec3 SnapToFixturePerimeter(const glm::vec3& p) const;

    // Pick the nearest node marker of the currently edited Complex vent to the
    // mouse ray; returns its node index or -1 if none is within the marker hit
    // radius.
    int  PickEditVentNode(int mouseX, int mouseY) const;

    // ---- Part 6: tangent-handle editing (smooth complex vents, Move tool) ---
    // Pick the nearest tangent-handle endpoint of the edited smooth vent to the
    // mouse ray. Returns the owning node index (and sets outIsOut = true for the
    // outgoing arm, false for the incoming arm) or -1 if none is in range.
    int  PickEditVentHandle(int mouseX, int mouseY, bool& outIsOut) const;

    // Drag a tangent handle to follow the cursor on the parting plane. Marks the
    // node hand-edited. breakLink (Alt) moves only the dragged arm and unlinks
    // the node; otherwise a linked node mirrors the opposite arm (symmetric).
    void MoveEditVentHandle(int node, bool isOut, int mouseX, int mouseY, bool breakLink);

    // Rebuild the GL line buffer that draws node->handle stems for the edited
    // smooth vent (called per frame while the handles are visible).
    void RebuildHandleLineVBO();

    // Insert a new node into the path of vent `ventIndex` at world point
    // `worldPt` (which the caller has snapped onto that vent's path). Selects
    // the vent, auto-converts Simple -> Complex, and splices the node into the
    // nearest segment so it lands between the two nodes that section spans.
    void InsertNodeOnVentAt(int ventIndex, const glm::vec3& worldPt);

    // Screen-space snap of the cursor onto an existing vent path (Add Node
    // tool). Mirrors RayCastEjectorSnap's runner snapping: returns the closest
    // point on any vent's RENDERED polyline within kEjectorSnapRadiusPx, plus
    // which vent it belongs to. Lets the user only place nodes on existing
    // paths, associating each new node with the path it snapped to.
    bool RayCastPathNodeSnap(int mouseX, int mouseY,
        glm::vec3& outPos, int& outVentIndex) const;

    // Remove node `idx` from the edited Complex vent. Origin (0) and endpoint
    // (last) are protected; interior nodes only. No-op if it would drop below
    // two nodes or idx is out of range.
    void RemoveEditVentNode(int idx);

    // Move node `idx` of the edited Complex vent to follow the mouse on the
    // parting plane. Origin re-snaps to a part edge (and recaptures parent),
    // the endpoint snaps to the fixture perimeter, interior nodes move freely.
    void MoveEditVentNode(int idx, int mouseX, int mouseY);

    // Hit-test the injection-point markers against the mouse ray; on a hit,
    // activate that point and (re)place the sprue. Returns true iff a point was
    // picked. Shared by SelectInjectionPoint mode and the EditSprue > Select
    // Injection Point sub-tool; the caller owns any mode transition.
    bool PickActivateInjectionPoint(int mouseX, int mouseY);

    // Map a world-space point into fixture-local space (injection-point coords).
    glm::vec3 WorldToFixtureLocal(const glm::vec3& world) const;

    // Unit inward normal (world XZ, y=0) of the fixture-perimeter edge nearest
    // ptXZ, oriented toward the origin — the default sprue direction for a
    // perimeter injection point (into the mould).
    glm::vec2 InwardPerimeterNormal(const glm::vec2& ptXZ) const;

    // ---- Part 7 / R5b: runner node authoring (parallels the vent methods) ----
    // The runner deltas: node[0] is PINNED to the sprue feed point (not
    // grabbable), the endpoint is FREE inside the perimeter (no snap), and all
    // nodes must stay inside the fixture hull.
    int  PickEditRunnerNode(int mouseX, int mouseY) const;   // nearest node marker, -1 if none
    void MoveEditRunnerNode(int idx, int mouseX, int mouseY);// drag endpoint/interior (node[0] pinned)
    void RemoveEditRunnerNode(int idx);                      // interior only; feed(0)+endpoint protected
    void InsertNodeOnRunnerAt(int runnerIndex, const glm::vec3& worldPt); // splice on the snapped path
    // Screen-space snap onto any runner's RENDERED polyline (Add Node tool).
    bool RayCastRunnerNodeSnap(int mouseX, int mouseY,
        glm::vec3& outPos, int& outRunnerIndex) const;

    // ---- Gate SUB-RUNNER node authoring (G5b) ------------------------------
    // Mirrors the runner node methods, with the gate twist that node[0] is the
    // gate origin (pinned — clicking it re-places the GATE instead of grabbing a
    // node) and the endpoint is FREE with snap-assist to the feed network.
    int  PickEditGateNode(int mouseX, int mouseY) const;   // nearest sub-runner node, -1 if none
    void MoveEditGateNode(int idx, int mouseX, int mouseY);// drag endpoint/interior (node[0] pinned)
    void RemoveEditGateNode(int idx);                      // interior only; origin(0)+endpoint protected
    void InsertNodeOnGateAt(int gateIndex, const glm::vec3& worldPt); // splice on the snapped sub-runner
    bool RayCastGateNodeSnap(int mouseX, int mouseY,
        glm::vec3& outPos, int& outGateIndex) const;
    // Nearest feed attach point (sprue parting pt or any runner centreline) to a
    // parting-plane XZ; false if there is no feed network. Endpoint snap-assist.
    bool NearestFeedPoint(const glm::vec2& xz, glm::vec3& outFeed) const;

    // ---- Part 7 / R6: runner tangent-handle editing (mirrors the vent Part-6
    // handle machinery, reusing m_editHandle* state + the handle-line VAO). The
    // feed node (0) exposes only its outgoing arm and the endpoint only its
    // incoming arm, exactly as for vents; the feed POSITION stays pinned.
    int  PickEditRunnerHandle(int mouseX, int mouseY, bool& outIsOut) const;
    void MoveEditRunnerHandle(int node, bool isOut, int mouseX, int mouseY, bool breakLink);

    // ---- G6: gate SUB-RUNNER tangent-handle editing (mirrors the runner R6
    // machinery, reusing the same m_editHandle* state + handle-line VAO). node[0]
    // (the gate origin) exposes only its outgoing arm, the endpoint only its
    // incoming arm; node[0]'s POSITION stays pinned to the gate.
    int  PickEditGateHandle(int mouseX, int mouseY, bool& outIsOut) const;
    void MoveEditGateHandle(int node, bool isOut, int mouseX, int mouseY, bool breakLink);

    // Reposition the floating toolbar to the top-centre of the viewport.
    void RepositionPathToolbar();

    void NotifyPathEditChanged() { if (m_onPathEditChanged) m_onPathEditChanged(); }

    // Vent cross-section geometry
    VentCrossSection BuildVentCrossSection(const VentPath& path,
        float width, float depth);
    void             RebuildCrossSectionVBO();

    // Vent solid is now built via free function BuildBoxSweepMesh() in MouldFeature.h

    // World-space ray cast against imported objects (no mouse unprojection).
    // Fires from 'origin' along 'dir' up to 'maxDist' world units.
    // Returns true and fills outPos with the closest hit; outPos is undefined on miss.
    bool RayCastWorldRay(const glm::vec3& origin, const glm::vec3& dir,
        float maxDist, glm::vec3& outPos);

    // Sprue path GPU upload
    void RebuildSpruePathVBO();

    // Sprue cross-section circle GPU upload (N-segment line-loop approximation)
    void RebuildSprueXsecVBO();

    // Runner path lines GPU upload (sprue parting point → each runner point)
    void RebuildRunnerPathVBO();

    // Runner solid geometry — swept cylinders from sprue parting point to each runner point
    void RebuildRunnerSolids();

    // Part 7 (R1): derive a runner's Simple FeaturePath (start = sprue feed
    // point, end = runner point) into rf.path.  Pure bookkeeping — it keeps the
    // stored path in sync as the sprue or runner point move so later steps can
    // author a Complex route in its place; it drives no geometry yet.
    void ComputeRunnerPath(RunnerFeature& rf) const;

    // Gate feed-attach bookkeeping — derives each gate's pathEnd / hasPath
    // (Simple: nearest feed; Complex: the authored endpoint). Runs BEFORE
    // ComputeGatePath (which needs a Simple gate's pathEnd). Does NOT upload the
    // guide-line VBO — that is RebuildGateLineVBO, run AFTER the sub-runner is
    // finalised so a bent complex line always matches the tube.
    void RebuildGatePathVBO();

    // Uploads the yellow gate guide lines from each gate's finalised subPath
    // (Simple: straight origin→feed; Complex: the real bent centreline). Called
    // at the end of RebuildGateSolids.
    void RebuildGateLineVBO();

    // Gate step G1: derive a gate's SUB-RUNNER Simple FeaturePath (start = gate
    // origin, end = feed attach point / pathEnd) into gf.subPath.  Runs at the
    // top of RebuildGateSolids so pathEnd is already fresh.  Pure bookkeeping —
    // it keeps the stored sub-runner path in sync as the gate or feed network
    // move so later steps can author a Complex route in its place; it drives no
    // geometry yet (the frustum + sub-runner are still built from pathEnd).
    void ComputeGatePath(GateFeature& gf) const;

    // Gate and sub-runner solid geometry
    void RebuildGateSolids();

    // Cylinder/frustum mesh is now built via free function BuildCylinderMesh() in MouldFeature.h

    // Build a world-space ray from mouse coordinates (shared by remove modes)
    void BuildMouseRay(int mouseX, int mouseY,
        glm::vec3& outOrigin, glm::vec3& outDir);

    // Fixture outer perimeter on the parting plane (convex hull in XZ)
    void                   BuildFixturePerimeter();
    std::vector<glm::vec2> m_fixturePerimeter;   // hull vertices in CCW order

    // World-space AABB enclosing every scene body (m_objects + m_inserts) with
    // the origin folded in as a zero-size point, so the result always contains
    // (0,0,0). An empty scene returns the degenerate origin-only box (min ==
    // max == 0). Used to size Dynamic fixtures (see CreateProceduralFixture).
    void ComputeSceneEnvelope(glm::vec3& outMin, glm::vec3& outMax) const;

    // (Re)build one procedural fixture half's box geometry (OCC blank + preview
    // mesh) in place for the given world-space corners, leaving role /
    // sourcePath / pose alone. Shared by CreateProceduralFixture and the
    // Dynamic live-resize path.
    void UpdateBoxHalf(SceneObject& half, const glm::vec3& lo, const glm::vec3& hi);

    // Project a ray from the origin along dirXZ onto the fixture perimeter's
    // axis-aligned bounds; returns the world boundary point at y=0. Gives a
    // perimeter location that tracks a chosen direction as a Dynamic box
    // resizes (vs. drifting to the nearest edge).
    glm::vec3 PerimeterPointInDirection(const glm::vec2& dirXZ) const;

    // Activate a default (front-centre) perimeter injection point on a fresh
    // procedural fixture so the sprue tools work immediately.
    void SeedPerimeterInjectionPoint();

    // Sphere mesh for vent point markers
    void BuildSphereGPU(float radius, int stacks, int slices);

    // ---- Align Face ---------------------------------------------------------
    // Pick a triangle on an imported model and grow a coplanar region. Used
    // for hover highlighting and click-to-align. The seed triangle index lets
    // OnPaint detect when the hover changed and avoid redundant region growth.
    bool RayCastFacePick(int mouseX, int mouseY, int& outObj, int& outTri);

    // Ctrl+C / Ctrl+V: in-process clipboard for selected objects. Copy
    // captures the CPU mesh + transform of every currently-selected object
    // (no GPU handles, no mould, no parented features). Paste appends a
    // fresh SceneObject per clipboard entry at the world origin, retaining
    // rotation, scale, and mirror flags; the GPU mesh is rebuilt via the
    // same pipeline used by ImportFile and the pattern operations. After
    // pasting, m_selectedIndices is set to the newly-pasted objects so the
    // user can immediately drag them off the origin.
    void CopySelectedToClipboard();
    void PasteFromClipboard();

    // Build edge adjacency for the object's CPU mesh if not already built.
    void EnsureTriAdjacency(SceneObject& obj);

    // BFS from seedTri across edge-shared neighbors whose triangle normal is
    // within ~1° of the seed's normal. Output is in local (object) space.
    void GrowCoplanarFace(const SceneObject& obj, int seedTri,
        std::vector<uint32_t>& outTris, glm::vec3& outNormalLocal);

    // Upload world-space triangles for the highlighted face to m_alignHighlight*.
    // Pass an empty triangle list to clear the highlight.
    void RebuildAlignHighlightVBO(const SceneObject& obj,
        const std::vector<uint32_t>& tris);

    // Apply the rotation+translation that snaps an arbitrary plane (defined
    // by a local-space normal and a local-space anchor point on the plane)
    // onto the world Y=0 parting plane. The anchor is held fixed laterally
    // (X/Z) so the picked geometry stays put in screen space and only the
    // pose changes. Used by both AlignFace and AlignMidplane.
    void ApplyPlaneAlignmentToObject(int objIdx,
        const glm::vec3& planeNormalLocal,
        const glm::vec3& anchorLocal);

    // AlignFace: thin wrapper around ApplyPlaneAlignmentToObject that uses
    // the picked face's own normal and centroid.
    void ApplyAlignFaceToObject(int objIdx, const glm::vec3& nLocal,
        const std::vector<uint32_t>& faceTris);

    // AlignMidplane: combine the locked first face with a freshly-picked
    // second face into a midplane, then apply alignment.
    void ApplyAlignMidplaneToObject(int objIdx,
        const glm::vec3& n2Local,
        const std::vector<uint32_t>& faceTris2);

    // Build/clear the persistent locked-face overlay used in midplane mode.
    void RebuildMidplaneLockedVBO(const SceneObject& obj,
        const std::vector<uint32_t>& tris);

    // Decompose a YXZ-Euler rotation matrix back to (yaw, pitch, roll).
    // Handles the gimbal-lock case where pitch ≈ ±90°.
    static void DecomposeYXZ(const glm::mat3& R,
        float& yawDeg, float& pitchDeg, float& rollDeg);

private:
    wxGLContext* m_context = nullptr;
    bool         m_inited = false;

    OrbitCamera  m_camera;
    GridRenderer m_grid;
    shaders      m_shaders;

    // Current grid configuration and a deferred-apply flag. The flag lets
    // SetGridSettings work before the GL context exists: the settings are
    // pushed to m_grid in OnPaint once the grid program is ready.
    GridSettings m_gridSettings;
    bool         m_gridNeedsApply = true;

    // Grid-snap drag state (Select-mode object move). The drag applies screen
    // deltas, so snapping the object positions directly would feed the snapped
    // value back into the next frame's accumulation and the object would never
    // leave the first grid point. Instead the true (unsnapped) group anchor is
    // tracked here and the snap is derived from it each frame, which also lets
    // releasing Ctrl fall straight back to the unsnapped position.
    bool         m_snapDragActive = false;
    glm::vec3    m_snapDragTrueAnchor{ 0.0f };

    // Scene
    std::vector<SceneObject> m_fixtures;

    // Active fixture kind + the Dynamic clearance, remembered so scene
    // mutations can resize a Dynamic fixture's halves (Part 4). Set by
    // CreateProceduralFixture; reset to Library by the file-fixture path
    // (ImportFileAsFixture) so a swap back to a library fixture stops any
    // dynamic resizing. Unused for Library / Parametric fixtures.
    FixtureKind m_fixtureKind = FixtureKind::Library;
    glm::vec3   m_dynamicClearance{ 10.0f };

    // Guards RebuildDynamicFixture against re-entry: its re-projection step
    // calls PlaceSprue, which fires NotifySceneMutated, which would call back
    // into RebuildDynamicFixture — infinite recursion without this latch.
    bool        m_rebuildingDynamicFixture = false;

    std::vector<SceneObject> m_objects;
    // Selected object indices into m_objects, in click order.
    // Last entry is the "primary" selection (used by single-seed operations
    // such as Pattern). Empty when nothing is selected.
    //   - Plain LMB on an unselected object: replaces the vector with {hit}.
    //   - Plain LMB on an already-selected object: leaves the vector alone
    //     (so a subsequent drag moves the whole group).
    //   - Plain LMB miss: clears the vector.
    //   - Ctrl+LMB on an object: toggles that index in the vector.
    //   - Ctrl+A: fills the vector with every object index.
    std::vector<int>         m_selectedIndices;

    // In-process clipboard populated by Ctrl+C and consumed by Ctrl+V.
    // Stores only the data needed to rebuild a SceneObject from scratch:
    // CPU mesh (so the paste can re-run the normal/crease pipeline and
    // upload its own GPU buffers), source path/shape (so future operations
    // like mould generation and export still see a real BREP), role, and
    // pose minus position. Position is intentionally not captured — paste
    // always places the new object at the world origin per spec.
    //
    // Notably absent: GPUMesh handles (each paste owns its own GPU
    // resources, and stashing live handles here would risk double-free if
    // the source object got deleted before paste); mouldShape/hasMould
    // (matches pattern-op behavior — user re-generates the mould after
    // duplicating); and any parented vents/gates (also matches pattern-op
    // conservatism — the original retains its features, the copy starts
    // clean).
    struct ClipboardEntry
    {
        std::vector<float>    cpuVerts;
        std::vector<uint32_t> cpuIndices;
        std::string           sourcePath;
        TopoDS_Shape          sourceShape;
        bool                  hasSourceShape = false;
        ObjectRole            role = ObjectRole::Imported;
        SourceFormat          format = SourceFormat::Brep;

        float yawDeg = 0.0f;
        float pitchDeg = 0.0f;
        float rollDeg = 0.0f;
        float scale = 1.0f;
        bool  mirrorX = false;
        bool  mirrorZ = false;
    };
    std::vector<ClipboardEntry> m_clipboard;

    // ---- Preview perspective state -----------------------------------------
    // True only for the dedicated preview canvas hosted by PreviewPanel. The
    // main editing canvas leaves this false and behaves exactly as before.
    bool m_previewMode = false;

    // One entry per part shown in the preview (mould halves + the shot). The
    // SceneObject carries its own GPU mesh (uploaded into the preview canvas's
    // context) at an identity pose — the fixture transform is already baked
    // into the world-space vertices handed to AddPreviewHalf. `label` drives
    // the part's show/hide toggle text; `visible` is flipped by that toggle;
    // `baseColor` lets the shot read distinctly from the grey mould halves.
    struct PreviewHalf
    {
        SceneObject obj;
        std::string label;
        bool        visible = true;
        glm::vec3   baseColor{ 0.80f, 0.80f, 0.85f };
    };
    std::vector<PreviewHalf> m_previewHalves;

    // Debug colouring overlay for one preview part (the shot). When active, the
    // named part is drawn as a set of flat-coloured groups instead of its
    // normal single colour. The debug VAO references the part's existing vertex
    // buffer, so only the per-group index buffers are owned here. GPU objects
    // are freed on the next SetShotDebugGroups call or by context teardown.
    struct DebugGroupGPU
    {
        GLuint    ebo = 0;
        GLsizei   count = 0;
        glm::vec3 color{ 0.5f };
        bool      emissive = false;
    };
    struct ShotDebugView
    {
        bool    active = false;
        int     halfIndex = -1;
        GLuint  vao = 0;
        std::vector<DebugGroupGPU> groups;
    };
    ShotDebugView m_shotDebug;

    // Accessibility-ray debug overlay (preview): ray segments drawn as GL_LINES
    // and contact points as GL_POINTS via the flat shader. Geometry is world
    // space; visibility of each is toggled independently.
    GLuint  m_debugRayVao = 0;
    GLuint  m_debugRayVbo = 0;
    GLsizei m_debugRayVertCount = 0;
    GLuint  m_debugContactVao = 0;
    GLuint  m_debugContactVbo = 0;
    GLsizei m_debugContactVertCount = 0;
    bool    m_showDebugRays = false;
    bool    m_showDebugContacts = false;

    // Free-standing lit debug solid (the separation test's interference region).
    // Stored as a SceneObject so the normal mesh upload/render path applies.
    SceneObject m_debugSolidObj;
    bool        m_showDebugSolid = false;
    glm::vec3   m_debugSolidColor{ 0.90f, 0.15f, 0.15f };

    // Meshes from the most recent successful GenerateMould (one per fixture,
    // world-space, position+normal interleaved with indices). Populated in
    // GenerateMould and consumed by PreviewPanel via GetLastMouldMeshes().
    // The main canvas no longer swaps these into its own fixtures — they live
    // here purely to seed the preview window.
    std::vector<FileImporter::MeshData> m_lastMouldMeshes;

    // The shot model from the most recent successful GenerateMould: union of
    // all imported objects + feed features (sprue / runners / gates), minus
    // vents and ejectors. World-space, position+normal interleaved with
    // indices. m_hasLastShotMesh is false when no shot could be built (no
    // contributing geometry, or the boolean union produced nothing usable).
    FileImporter::MeshData m_lastShotMesh;
    bool                   m_hasLastShotMesh = false;

    // Volume of the shot solid (cubic mm), computed from the fused BREP at
    // generation time. Zero when no shot was built.
    double                 m_lastShotVolumeMm3 = 0.0;

    // The "Cast Shot Body": the standard shot fused with the features left out
    // of it — vents, inserts (grown by the Cut scale) and ejector pins. Built
    // at generation time for the cast-mould bases; not displayed on its own.
    // The BREP solid is retained alongside its tessellation so the cast bases
    // can be built as BREP (STEP-exportable) in a BREP scene.
    FileImporter::MeshData m_lastCastShotMesh;
    TopoDS_Shape           m_lastCastShotShape;
    bool                   m_hasLastCastShotMesh = false;

    // The shot solid (BREP) and a per-display-triangle face-index map, kept so
    // design checks can run at the face level and map results back to the
    // display triangles. Face indices are 1-based into a TopExp::MapShapes
    // face map of m_lastShotShape, matching what DesignChecks rebuilds.
    TopoDS_Shape           m_lastShotShape;
    std::vector<int>       m_lastShotFaceIds;

    // The post-cut mould-half solids (BREP), in fixture order, retained for the
    // separation-based demoldability check.
    std::vector<TopoDS_Shape> m_lastHalfShapes;

    // Display meshes of the inserts as they stood at the most recent
    // GenerateMould (world-space, tessellated from each insert's UNSCALED body
    // — the same void removed from the shot). One per insert. Consumed by
    // PreviewPanel via GetLastInsertMeshes so the preview can show the inserts
    // as their own category, in the same yellow they use in the Prepare view.
    // Empty when there were no inserts.
    std::vector<FileImporter::MeshData> m_lastInsertMeshes;


    // Vent features (consolidated: point + path + cross-section + solid)
    std::vector<VentInstance> m_vents;

    // Sprue state (consolidated)
    InjectionPoint m_activeInjectionPoint;         // set from fixture on load
    bool           m_hasActiveInjectionPoint = false;
    std::vector<InjectionPoint> m_injectionPoints; // all points from fixture
    SprueFeature   m_sprue;

    // Ghost preview for vent placement (follows mouse in PlaceVent mode)
    VentPoint m_ventGhost;
    bool      m_ventGhostActive = false;
    wxPoint   m_ghostMousePos;          // last known cursor pos, ray cast deferred to OnPaint

    // Runner features (consolidated: point + solid + cold plug solid)
    std::vector<RunnerFeature> m_runners;

    // Ghost preview for runner placement (follows mouse in PlaceRunner mode)
    glm::vec3 m_runnerGhostPos{ 0.0f };
    bool      m_runnerGhostActive = false;
    wxPoint   m_runnerGhostMousePos;

    // Gate features
    std::vector<GateFeature> m_gates;

    // Ghost preview for gate placement (follows mouse in PlaceGate mode)
    VentPoint m_gateGhost;
    bool      m_gateGhostActive = false;
    wxPoint   m_gateGhostMousePos;

    // Ejector features (placement points only, geometry TBD)
    std::vector<EjectorFeature> m_ejectors;

    // Indexer features (placement points only, geometry TBD — see
    // IndexerFeature in MouldFeature.h). Always on y=0, so unlike the ejector
    // ghost this one needs no separate "which surface did it snap to" state —
    // RayCastToPartingPlane either hits the plane or it doesn't.
    std::vector<IndexerFeature> m_indexers;
    glm::vec3 m_indexerGhostPos{ 0.0f };
    bool      m_indexerGhostActive = false;
    wxPoint   m_indexerGhostMousePos;

    // Imported insert bodies. Separate from m_objects by design — see
    // InsertFeature. No ghost-preview flag: placement is parent-pick +
    // file dialog, not a cursor-tracked drop, so there is nothing to ghost.
    std::vector<InsertFeature>  m_inserts;

    // Monotonic source of InsertFeature::id. Never decremented, so ids are
    // never reused within a session and a stale dialog reference resolves to
    // "gone" rather than silently retargeting a different insert.
    int                         m_nextInsertId = 0;

    // Ghost preview for ejector placement (follows mouse in PlaceEjector mode).
    // No normal field — see EjectorFeature comment in MouldFeature.h.
    glm::vec3 m_ejectorGhostPos{ 0.0f };
    bool      m_ejectorGhostActive = false;
    wxPoint   m_ejectorGhostMousePos;

    // Fallback test geometry (pyramid)
    unsigned int m_vao = 0;
    unsigned int m_vbo = 0;
    unsigned int m_ebo = 0;

    // Shader programs
    unsigned int m_program = 0;
    GLuint       m_pickProgram = 0;
    GLuint       m_outlineProgram = 0;

    // Sphere GPU resources (vent point markers)
    GLuint  m_sphereVAO = 0;
    GLuint  m_sphereVBO = 0;
    GLuint  m_sphereEBO = 0;
    GLsizei m_sphereIndexCount = 0;

    // Vent path line GPU resources
    GLuint  m_pathVAO = 0;
    GLuint  m_pathVBO = 0;
    GLsizei m_pathVertexCount = 0;

    // Sprue path/xsec GPU resources now live inside m_sprue (SprueFeature)

    // Runner path line GPU resources (sprue parting point → each runner point)
    GLuint  m_runnerPathVAO = 0;
    GLuint  m_runnerPathVBO = 0;
    GLsizei m_runnerPathVertexCount = 0;

    // Gate path line GPU resources (gate point → nearest feed point)
    GLuint  m_gatePathVAO = 0;
    GLuint  m_gatePathVBO = 0;
    GLsizei m_gatePathVertexCount = 0;

    // Vent cross-section GPU resources
    GLuint  m_xsecVAO = 0;
    GLuint  m_xsecVBO = 0;
    GLsizei m_xsecVertexCount = 0;

    // Flat (unlit) shader for vent path lines
    GLuint m_flatProgram = 0;
    GLint  m_flat_uVP = -1;
    GLint  m_flat_uColor = -1;

    // Fixture-perimeter highlight loop (Fixture Perimeter injection). A dynamic
    // GL_LINE_LOOP uploaded from m_fixturePerimeter in the render pass while the
    // Select Injection Point tool is active and perimeter injection is allowed.
    GLuint m_perimeterVAO = 0;
    GLuint m_perimeterVBO = 0;

    // Uniform locations — picking
    GLint m_pick_uMVP = -1;
    GLint m_pick_uObjectId = -1;

    // Uniform locations — outline
    GLint m_outline_uIdTex = -1;
    GLint m_outline_uTargetId = -1;
    GLint m_outline_uTexSize = -1;
    GLint m_outline_uAlpha = -1;
    GLint m_outline_uThickness = -1;

    GLuint m_fullscreenVAO = 0;

    // Mouse state
    bool    m_lmb = false;
    bool    m_mmb = false;
    bool    m_rmb = false;
    bool    m_hasLast = false;
    wxPoint m_lastPos;

    // Transform mode
    TransformMode m_transformMode = TransformMode::Select;

    // Edit mode state — index of the currently selected feature (-1 = none)
    int     m_editFeatureIndex = -1;
    wxPoint m_editMousePos;              // deferred mouse position for edit drag
    bool    m_editNeedsUpdate = false;   // true when edit drag needs processing in OnPaint

    // ---- Part 5: complex vent-path authoring state -------------------------
    PathEditTool m_pathEditTool = PathEditTool::Move;  // active EditVent sub-tool
    int          m_editVentNode = -1;   // node being dragged (Move tool), -1 = none
    int          m_editRunnerNode = -1; // runner node being dragged (Move tool), -1 = none
    int          m_editGateNode = -1;   // gate sub-runner node being dragged (Move tool), -1 = none

    // ---- Edit Sprue environment state --------------------------------------
    SprueEditTool m_sprueEditTool = SprueEditTool::Move;  // active EditSprue sub-tool
    bool          m_sprueEndpointGrabbed = false;         // radial endpoint held (Move drag)
    bool          m_sprueInjectionGrabbed = false;        // perimeter injection point held (Move drag)
    bool          m_allowPerimeterInjection = false;      // fixture permits perimeter injection

    // m_edit*Node doubles as "selected node" (it survives the mouse release so
    // the toolbar and the enlarged marker can act on it) AND as "node the next
    // drag moves". Those two meanings diverged once selecting a PATH began
    // auto-selecting its end node: a press on empty space would then have
    // dragged the end node instead of re-placing / orbiting. This flag keeps
    // them apart - set only when the mouse-down actually grabbed a node, and
    // it alone licenses the deferred drag to move one.
    bool         m_editNodeGrabbed = false;
    wxWindow*    m_pathToolbar  = nullptr;  // floating toolbar overlay (opaque)
    wxWindow*    m_sprueToolbar = nullptr;  // Edit Sprue toolbar overlay (opaque)
    wxWindow*    m_canvasToast  = nullptr;  // bottom-centre hint overlay (opaque)
    std::function<void()> m_onPathEditChanged;  // toolbar reconfigure hook

    // Add Node ghost — snaps onto an existing vent path under the cursor.
    glm::vec3 m_pathNodeGhostPos{ 0.0f };
    bool      m_pathNodeGhostActive = false;
    wxPoint   m_pathNodeGhostMousePos;

    // ---- Part 6: tangent-handle drag state ---------------------------------
    int    m_editHandleNode = -1;     // node whose handle is grabbed (-1 = none)
    bool   m_editHandleIsOut = false; // true = outgoing arm, false = incoming
    bool   m_editHandleBreak = false; // Alt held during the current handle drag
    GLuint  m_handleLineVAO = 0;      // node->handle stems (flat program)
    GLuint  m_handleLineVBO = 0;
    GLsizei m_handleLineVertexCount = 0;

    // Picking FBO
    GLuint m_pickFBO = 0;
    GLuint m_pickColorTex = 0;
    GLuint m_pickDepthRb = 0;
    int    m_pickW = 0;
    int    m_pickH = 0;

    // ---- Align Face state ---------------------------------------------------
    // Hover state for AlignFace mode. Mouse position is captured in OnMouse
    // and the ray cast is deferred to OnPaint (one cast per frame).
    wxPoint               m_alignMousePos;
    int                   m_alignHoverObject = -1;
    int                   m_alignSeedTri = -1;       // last grown seed; -1 = no hover
    std::vector<uint32_t> m_alignFaceTris;           // tris in current hover region
    glm::vec3             m_alignFaceNormalLocal{ 0.0f };

    // GPU resources for the dark-grey highlight overlay (world-space triangles).
    GLuint  m_alignHighlightVAO = 0;
    GLuint  m_alignHighlightVBO = 0;
    GLsizei m_alignHighlightVertexCount = 0;

    // ---- Align Midplane state ----------------------------------------------
    // Locked first-face state for two-click midplane alignment. Reuses the
    // hover state above for the current cursor highlight, and adds a separate
    // VBO for the persistent locked-face overlay (yellow, matches selection
    // outline). Object-local data is captured at click time so subsequent
    // mouse motion or transforms don't invalidate it.
    bool                  m_midplaneFaceLocked = false;
    int                   m_midplaneFaceObject = -1;
    std::vector<uint32_t> m_midplaneFaceTris;
    glm::vec3             m_midplaneFaceNormalLocal{ 0.0f };
    glm::vec3             m_midplaneFaceCentroidLocal{ 0.0f };

    GLuint  m_midplaneLockedVAO = 0;
    GLuint  m_midplaneLockedVBO = 0;
    GLsizei m_midplaneLockedVertexCount = 0;

    // ---- Scene mutation observer ------------------------------------------
    // Registered by MainFrame to invalidate the Export button. Fired from
    // mutation methods via NotifySceneMutated() below — see SetOnSceneMutated
    // (public, near GenerateMould) for the user-facing contract.
    std::function<void()> m_onSceneMutated;

    // Helper: fire the scene-mutation callback if one is registered. Called
    // from every mutating method on this class. Synchronous — the callback
    // runs on the wxWidgets main thread before the mutating method returns.
    void NotifySceneMutated()
    {
        // A Dynamic fixture auto-fits the scene, so resize it on every change
        // that routes through here — transforms, patterns, and feature/insert
        // edits. (Object import / delete / paste don't call this, so they
        // resize at their own sites.) No-op for Library / Parametric fixtures.
        // Done before the external callback so observers see the up-to-date
        // fixture geometry.
        RebuildDynamicFixture();
        if (m_onSceneMutated) m_onSceneMutated();
    }

    // ---- Scene mesh-type tracking ------------------------------------------
    // True when at least one mesh-format (STL/OBJ) body is in the scene. See
    // IsSceneMeshType() for the public contract.
    bool m_sceneIsMesh = false;

    // Rescan m_objects + m_inserts and refresh m_sceneIsMesh. When `notify`
    // is true and the flag transitions false->true, shows the one-time
    // "switched to mesh toolpath" notice. A downward true->false transition
    // (last mesh body removed) is silent — the user only asked to be told
    // when the scene BECOMES a mesh scene. Cheap (linear scan); safe to call
    // after any add/remove.
    void RecomputeSceneMeshType(bool notify);

    // Map a source-file extension to its lineage: .stl / .obj -> Mesh, every
    // other (including .step / .stp and unknown) -> Brep.
    static SourceFormat FormatFromPath(const std::string& path);

    // Transform a local position-only mesh (cpuVerts/cpuIndices) into a
    // world-space MeshBoolean::Mesh by `model`. If `model` has negative
    // determinant (a mirror), triangle winding is reversed so the solid stays
    // outward-oriented for the mesh boolean. Used to place mesh objects/inserts
    // into world space for the mesh-toolpath cut in GenerateMould.
    static MeshBoolean::Mesh WorldMeshFromLocal(
        const std::vector<float>& cpuVerts,
        const std::vector<uint32_t>& cpuIndices,
        const glm::mat4& model);
};
